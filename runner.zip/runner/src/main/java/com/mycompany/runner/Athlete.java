/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.runner;

/**
 *
 * @author 2167543
 */
public class Athlete {
    // The Athlete's first name
    private String fName;
    
    // The Athlete's last name
    private String lName;
    
    // The Athlete's position
    private String position;
    
    // The total number of points the Athlete has scored
    private String totalPoints;
}
