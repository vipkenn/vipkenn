/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.runner;

/**
 *
 * @author 2167543
 */
public class Sport {
     // This variable will hold the name of a given sport
    private String name;
    
    // This variable will hold the number of teams that participate in a given match/game
    private int numTeamsPerMatch;
    
    // This variable will hold the number of players per team
    private int numPlayersPerTeam;
}

